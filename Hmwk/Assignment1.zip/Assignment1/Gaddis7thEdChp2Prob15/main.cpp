/* 
 * File:   main.cpp
 * Author: Tracy Quintos
 *Created on June 26, 2014, 4:12 AM
 * Purpose:Homework Gaddis7thEdChp2Prob15
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    cout <<"   *   \n"<<endl;
    cout <<"  ***  \n"<<endl;
    cout <<" ***** \n"<<endl;
    cout <<"*******\n\n"<<endl;      
    return 0;
}


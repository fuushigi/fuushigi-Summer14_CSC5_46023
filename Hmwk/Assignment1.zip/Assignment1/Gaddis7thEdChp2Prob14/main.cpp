/* 
 * File:   main.cpp
 * Author: Tracy Quintos 
 *Created on June 26, 2014, 4:54 AM
 *Purpose: Homework Gaddis7thEdChp2Prob14
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
   

//Using a single cout statement as directed by book
cout<<"Tracy Quitos"<<endl<<"13182 Kochi Dr Moreno Valley, Ca, 92553"<<endl<<"#951-653-9577"<<endl<<"Computer Science";
    
   
  return 0;
}


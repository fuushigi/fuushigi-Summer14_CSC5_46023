/* 
 * File:   main.cpp
 * Author: Tracy Quintos
 * Created on June 26, 2014, 5:15 AM
 * Purpose: Homework Gaddis7thEdChp2Prob1
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    int num1=62, num2=99, total=161;
    
    cout<<"Please enter 62"<<endl;
    cin >>num1;
    
    cout<<"Please enter 99"<<endl;
    cin >>num2;
    
    total = num1 + num2;
    
    cout<<"The sum of the total is: "<<total<<endl;
    
    return 0;
 
  
}

